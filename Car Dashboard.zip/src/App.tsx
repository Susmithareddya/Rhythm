import { useState, useEffect } from 'react';
import { SpeedGauge } from './components/SpeedGauge';
import { RPMGauge } from './components/RPMGauge';
import { FuelGauge } from './components/FuelGauge';
import { TemperatureGauge } from './components/TemperatureGauge';
import { WarningLights } from './components/WarningLights';
import { TripInfo } from './components/TripInfo';
import { StatusBar } from './components/StatusBar';

export default function App() {
  const [speed, setSpeed] = useState(0);
  const [rpm, setRpm] = useState(0);
  const [fuel, setFuel] = useState(75);
  const [temperature, setTemperature] = useState(90);
  const [gear, setGear] = useState('P');

  // Simulate driving dynamics
  useEffect(() => {
    const interval = setInterval(() => {
      // Simulate speed changes
      setSpeed(prev => {
        const change = (Math.random() - 0.5) * 5;
        const newSpeed = Math.max(0, Math.min(200, prev + change));
        return Math.round(newSpeed);
      });

      // RPM follows speed with some variation
      setRpm(prev => {
        const targetRpm = speed * 30 + Math.random() * 500;
        const newRpm = prev + (targetRpm - prev) * 0.1;
        return Math.max(0, Math.min(8000, Math.round(newRpm)));
      });

      // Slowly decrease fuel
      setFuel(prev => Math.max(0, prev - 0.01));

      // Temperature stabilizes around 90
      setTemperature(prev => {
        const target = 90;
        return prev + (target - prev) * 0.05;
      });

      // Update gear based on speed
      if (speed === 0) setGear('P');
      else if (speed < 15) setGear('1');
      else if (speed < 30) setGear('2');
      else if (speed < 50) setGear('3');
      else if (speed < 70) setGear('4');
      else if (speed < 90) setGear('5');
      else setGear('6');
    }, 100);

    return () => clearInterval(interval);
  }, [speed]);

  return (
    <div className="min-h-screen bg-gradient-to-b from-gray-900 via-gray-800 to-black text-white flex items-center justify-center p-4">
      <div className="w-full max-w-7xl">
        {/* Top Status Bar */}
        <StatusBar />

        {/* Main Dashboard */}
        <div className="grid grid-cols-1 lg:grid-cols-3 gap-6 mt-6">
          {/* Left Section - RPM */}
          <div className="flex flex-col items-center justify-center">
            <RPMGauge value={rpm} />
            <div className="mt-4 text-center">
              <div className="text-gray-400 text-sm">RPM × 1000</div>
            </div>
          </div>

          {/* Center Section - Speed & Gear */}
          <div className="flex flex-col items-center justify-center">
            <SpeedGauge value={speed} />
            <div className="mt-8 text-center">
              <div className="text-6xl font-bold mb-2">{gear}</div>
              <div className="text-gray-400 text-sm">GEAR</div>
            </div>
            <WarningLights speed={speed} fuel={fuel} temperature={temperature} />
          </div>

          {/* Right Section - Fuel & Temp */}
          <div className="flex flex-col items-center justify-center space-y-8">
            <FuelGauge value={fuel} />
            <TemperatureGauge value={temperature} />
          </div>
        </div>

        {/* Bottom Info */}
        <TripInfo speed={speed} fuel={fuel} />
      </div>
    </div>
  );
}
