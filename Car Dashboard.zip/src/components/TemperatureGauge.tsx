import { Thermometer } from 'lucide-react';
import { motion } from 'motion/react';

interface TemperatureGaugeProps {
  value: number;
}

export function TemperatureGauge({ value }: TemperatureGaugeProps) {
  const percentage = Math.max(0, Math.min(100, (value / 120) * 100));
  const isHot = value > 100;

  return (
    <div className="w-full max-w-xs">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Thermometer className={`w-5 h-5 ${isHot ? 'text-red-500' : 'text-cyan-400'}`} />
          <span className="text-sm text-gray-400">TEMP</span>
        </div>
        <span className={`${isHot ? 'text-red-500' : 'text-white'}`}>
          {value.toFixed(0)}°C
        </span>
      </div>
      
      <div className="relative h-3 bg-gray-700 rounded-full overflow-hidden">
        <motion.div
          className={`h-full rounded-full ${
            isHot
              ? 'bg-gradient-to-r from-orange-500 to-red-500'
              : 'bg-gradient-to-r from-cyan-500 to-blue-500'
          }`}
          initial={{ width: '0%' }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.5 }}
        />
        
        {isHot && (
          <motion.div
            className="absolute inset-0 bg-red-500 rounded-full"
            animate={{ opacity: [0.3, 0.8, 0.3] }}
            transition={{ duration: 1, repeat: Infinity }}
            style={{ width: `${percentage}%` }}
          />
        )}
      </div>
      
      <div className="flex justify-between mt-1 text-xs text-gray-500">
        <span>C</span>
        <span>H</span>
      </div>
    </div>
  );
}
