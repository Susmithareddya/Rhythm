import { Bluetooth, Radio, MapPin, Clock } from 'lucide-react';
import { useState, useEffect } from 'react';

export function StatusBar() {
  const [time, setTime] = useState(new Date());

  useEffect(() => {
    const interval = setInterval(() => {
      setTime(new Date());
    }, 1000);

    return () => clearInterval(interval);
  }, []);

  const formattedTime = time.toLocaleTimeString('en-US', {
    hour: '2-digit',
    minute: '2-digit',
    hour12: true,
  });

  const formattedDate = time.toLocaleDateString('en-US', {
    weekday: 'short',
    month: 'short',
    day: 'numeric',
  });

  return (
    <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
      <div className="flex items-center justify-between">
        {/* Left Section - Connectivity */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-blue-400">
            <Bluetooth className="w-5 h-5" />
            <span className="text-sm">Connected</span>
          </div>
          <div className="flex items-center gap-2 text-green-400">
            <Radio className="w-5 h-5" />
            <span className="text-sm">FM 101.5</span>
          </div>
        </div>

        {/* Center Section - Time & Date */}
        <div className="text-center">
          <div className="text-3xl">{formattedTime}</div>
          <div className="text-sm text-gray-400">{formattedDate}</div>
        </div>

        {/* Right Section - Location & Weather */}
        <div className="flex items-center gap-4">
          <div className="flex items-center gap-2 text-cyan-400">
            <MapPin className="w-5 h-5" />
            <span className="text-sm">San Francisco</span>
          </div>
          <div className="text-sm">
            <div>72°F</div>
            <div className="text-gray-400">Sunny</div>
          </div>
        </div>
      </div>
    </div>
  );
}
