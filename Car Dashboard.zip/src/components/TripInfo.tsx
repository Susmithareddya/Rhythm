import { MapPin, Clock, Navigation } from 'lucide-react';
import { useState, useEffect } from 'react';

interface TripInfoProps {
  speed: number;
  fuel: number;
}

export function TripInfo({ speed, fuel }: TripInfoProps) {
  const [tripDistance, setTripDistance] = useState(247.3);
  const [tripTime, setTripTime] = useState(4.5);

  useEffect(() => {
    const interval = setInterval(() => {
      // Increment distance based on speed (simplified calculation)
      setTripDistance(prev => prev + (speed / 3600) * 0.1);
      setTripTime(prev => prev + 0.1 / 3600);
    }, 100);

    return () => clearInterval(interval);
  }, [speed]);

  const avgSpeed = tripTime > 0 ? tripDistance / tripTime : 0;
  const range = (fuel / 100) * 450; // Assume 450 miles on full tank

  return (
    <div className="mt-8 grid grid-cols-2 md:grid-cols-4 gap-4">
      <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
        <div className="flex items-center gap-2 text-gray-400 mb-2">
          <MapPin className="w-4 h-4" />
          <span className="text-sm">Trip Distance</span>
        </div>
        <div className="text-2xl">{tripDistance.toFixed(1)} mi</div>
      </div>

      <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
        <div className="flex items-center gap-2 text-gray-400 mb-2">
          <Clock className="w-4 h-4" />
          <span className="text-sm">Trip Time</span>
        </div>
        <div className="text-2xl">{Math.floor(tripTime)}h {Math.floor((tripTime % 1) * 60)}m</div>
      </div>

      <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
        <div className="flex items-center gap-2 text-gray-400 mb-2">
          <Navigation className="w-4 h-4" />
          <span className="text-sm">Avg Speed</span>
        </div>
        <div className="text-2xl">{avgSpeed.toFixed(0)} mph</div>
      </div>

      <div className="bg-gray-800/50 rounded-lg p-4 border border-gray-700">
        <div className="flex items-center gap-2 text-gray-400 mb-2">
          <MapPin className="w-4 h-4" />
          <span className="text-sm">Range</span>
        </div>
        <div className="text-2xl">{range.toFixed(0)} mi</div>
      </div>
    </div>
  );
}
