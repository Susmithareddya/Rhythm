import { motion } from 'motion/react';

interface RPMGaugeProps {
  value: number;
}

export function RPMGauge({ value }: RPMGaugeProps) {
  const maxRPM = 8000;
  const rotation = -135 + (value / maxRPM) * 270;
  const rpmDisplay = (value / 1000).toFixed(1);

  return (
    <div className="relative w-64 h-64">
      <svg className="w-full h-full" viewBox="0 0 200 200">
        {/* Outer Circle */}
        <circle
          cx="100"
          cy="100"
          r="90"
          fill="none"
          stroke="rgba(255,255,255,0.1)"
          strokeWidth="2"
        />
        
        {/* RPM Arc Background */}
        <path
          d="M 23.5 123.5 A 85 85 0 1 1 176.5 123.5"
          fill="none"
          stroke="rgba(255,255,255,0.1)"
          strokeWidth="20"
          strokeLinecap="round"
        />
        
        {/* RPM Arc - Active */}
        <motion.path
          d="M 23.5 123.5 A 85 85 0 1 1 176.5 123.5"
          fill="none"
          stroke={value > 6500 ? "#ef4444" : "url(#rpmGradient)"}
          strokeWidth="20"
          strokeLinecap="round"
          strokeDasharray="445"
          strokeDashoffset={445 - (value / maxRPM) * 445}
          initial={{ strokeDashoffset: 445 }}
          animate={{ strokeDashoffset: 445 - (value / maxRPM) * 445 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
        />
        
        {/* Gradient Definition */}
        <defs>
          <linearGradient id="rpmGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#10b981" />
            <stop offset="70%" stopColor="#f59e0b" />
            <stop offset="100%" stopColor="#ef4444" />
          </linearGradient>
        </defs>
        
        {/* Redline Zone */}
        <path
          d="M 158 60 A 85 85 0 0 1 176.5 123.5"
          fill="none"
          stroke="rgba(239, 68, 68, 0.3)"
          strokeWidth="20"
          strokeLinecap="round"
        />
        
        {/* Tick Marks */}
        {[...Array(17)].map((_, i) => {
          const angle = -135 + (i * 270) / 16;
          const isMajor = i % 2 === 0;
          const length = isMajor ? 15 : 10;
          const startRadius = 75;
          const endRadius = startRadius - length;
          
          const x1 = 100 + startRadius * Math.cos((angle * Math.PI) / 180);
          const y1 = 100 + startRadius * Math.sin((angle * Math.PI) / 180);
          const x2 = 100 + endRadius * Math.cos((angle * Math.PI) / 180);
          const y2 = 100 + endRadius * Math.sin((angle * Math.PI) / 180);
          
          return (
            <line
              key={i}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke={i >= 13 ? "rgba(239, 68, 68, 0.8)" : "rgba(255,255,255,0.6)"}
              strokeWidth={isMajor ? 2 : 1}
            />
          );
        })}
        
        {/* RPM Numbers */}
        {[0, 1, 2, 3, 4, 5, 6, 7, 8].map((num, i) => {
          const angle = -135 + (i * 270) / 8;
          const radius = 50;
          const x = 100 + radius * Math.cos((angle * Math.PI) / 180);
          const y = 100 + radius * Math.sin((angle * Math.PI) / 180);
          
          return (
            <text
              key={num}
              x={x}
              y={y}
              textAnchor="middle"
              dominantBaseline="middle"
              fill={num >= 7 ? "rgba(239, 68, 68, 0.9)" : "rgba(255,255,255,0.8)"}
              fontSize="12"
              fontWeight="600"
            >
              {num}
            </text>
          );
        })}
        
        {/* Center Dot */}
        <circle cx="100" cy="100" r="8" fill="#1f2937" />
        <circle cx="100" cy="100" r="6" fill="#10b981" />
        
        {/* Needle */}
        <motion.g
          initial={{ rotate: -135 }}
          animate={{ rotate: rotation }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          style={{ originX: '100px', originY: '100px' }}
        >
          <path
            d="M 100 100 L 98 100 L 100 30 L 102 100 Z"
            fill={value > 6500 ? "#ef4444" : "#10b981"}
            stroke="#fff"
            strokeWidth="1"
          />
        </motion.g>
      </svg>
      
      {/* RPM Display */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center mt-12">
          <div className="text-5xl font-bold">{rpmDisplay}</div>
        </div>
      </div>
    </div>
  );
}
