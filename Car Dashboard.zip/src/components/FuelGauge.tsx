import { Fuel } from 'lucide-react';
import { motion } from 'motion/react';

interface FuelGaugeProps {
  value: number;
}

export function FuelGauge({ value }: FuelGaugeProps) {
  const percentage = Math.max(0, Math.min(100, value));
  const isLow = percentage < 20;

  return (
    <div className="w-full max-w-xs">
      <div className="flex items-center justify-between mb-2">
        <div className="flex items-center gap-2">
          <Fuel className={`w-5 h-5 ${isLow ? 'text-red-500' : 'text-blue-400'}`} />
          <span className="text-sm text-gray-400">FUEL</span>
        </div>
        <span className={`${isLow ? 'text-red-500' : 'text-white'}`}>
          {percentage.toFixed(0)}%
        </span>
      </div>
      
      <div className="relative h-3 bg-gray-700 rounded-full overflow-hidden">
        <motion.div
          className={`h-full rounded-full ${
            isLow ? 'bg-red-500' : 'bg-gradient-to-r from-blue-500 to-blue-400'
          }`}
          initial={{ width: '100%' }}
          animate={{ width: `${percentage}%` }}
          transition={{ duration: 0.5 }}
        />
        
        {isLow && (
          <motion.div
            className="absolute inset-0 bg-red-500 rounded-full"
            animate={{ opacity: [0.3, 0.8, 0.3] }}
            transition={{ duration: 1, repeat: Infinity }}
            style={{ width: `${percentage}%` }}
          />
        )}
      </div>
      
      <div className="flex justify-between mt-1 text-xs text-gray-500">
        <span>E</span>
        <span>F</span>
      </div>
    </div>
  );
}
