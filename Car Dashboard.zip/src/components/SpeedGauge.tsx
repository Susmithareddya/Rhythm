import { motion } from 'motion/react';

interface SpeedGaugeProps {
  value: number;
}

export function SpeedGauge({ value }: SpeedGaugeProps) {
  // Calculate rotation angle (-135 to 135 degrees for 0-200 speed)
  const rotation = -135 + (value / 200) * 270;

  return (
    <div className="relative w-64 h-64">
      {/* Gauge Background */}
      <svg className="w-full h-full" viewBox="0 0 200 200">
        {/* Outer Circle */}
        <circle
          cx="100"
          cy="100"
          r="90"
          fill="none"
          stroke="rgba(255,255,255,0.1)"
          strokeWidth="2"
        />
        
        {/* Speed Arc Background */}
        <path
          d="M 23.5 123.5 A 85 85 0 1 1 176.5 123.5"
          fill="none"
          stroke="rgba(255,255,255,0.1)"
          strokeWidth="20"
          strokeLinecap="round"
        />
        
        {/* Speed Arc - Active */}
        <motion.path
          d="M 23.5 123.5 A 85 85 0 1 1 176.5 123.5"
          fill="none"
          stroke="url(#speedGradient)"
          strokeWidth="20"
          strokeLinecap="round"
          strokeDasharray="445"
          strokeDashoffset={445 - (value / 200) * 445}
          initial={{ strokeDashoffset: 445 }}
          animate={{ strokeDashoffset: 445 - (value / 200) * 445 }}
          transition={{ duration: 0.3, ease: "easeOut" }}
        />
        
        {/* Gradient Definition */}
        <defs>
          <linearGradient id="speedGradient" x1="0%" y1="0%" x2="100%" y2="0%">
            <stop offset="0%" stopColor="#3b82f6" />
            <stop offset="50%" stopColor="#8b5cf6" />
            <stop offset="100%" stopColor="#ef4444" />
          </linearGradient>
        </defs>
        
        {/* Tick Marks */}
        {[...Array(21)].map((_, i) => {
          const angle = -135 + (i * 270) / 20;
          const isMajor = i % 2 === 0;
          const length = isMajor ? 15 : 10;
          const startRadius = 75;
          const endRadius = startRadius - length;
          
          const x1 = 100 + startRadius * Math.cos((angle * Math.PI) / 180);
          const y1 = 100 + startRadius * Math.sin((angle * Math.PI) / 180);
          const x2 = 100 + endRadius * Math.cos((angle * Math.PI) / 180);
          const y2 = 100 + endRadius * Math.sin((angle * Math.PI) / 180);
          
          return (
            <line
              key={i}
              x1={x1}
              y1={y1}
              x2={x2}
              y2={y2}
              stroke="rgba(255,255,255,0.6)"
              strokeWidth={isMajor ? 2 : 1}
            />
          );
        })}
        
        {/* Speed Numbers */}
        {[0, 40, 80, 120, 160, 200].map((num, i) => {
          const angle = -135 + (i * 270) / 5;
          const radius = 50;
          const x = 100 + radius * Math.cos((angle * Math.PI) / 180);
          const y = 100 + radius * Math.sin((angle * Math.PI) / 180);
          
          return (
            <text
              key={num}
              x={x}
              y={y}
              textAnchor="middle"
              dominantBaseline="middle"
              fill="rgba(255,255,255,0.8)"
              fontSize="12"
              fontWeight="600"
            >
              {num}
            </text>
          );
        })}
        
        {/* Center Dot */}
        <circle cx="100" cy="100" r="8" fill="#1f2937" />
        <circle cx="100" cy="100" r="6" fill="#ef4444" />
        
        {/* Needle */}
        <motion.g
          initial={{ rotate: -135 }}
          animate={{ rotate: rotation }}
          transition={{ duration: 0.3, ease: "easeOut" }}
          style={{ originX: '100px', originY: '100px' }}
        >
          <path
            d="M 100 100 L 98 100 L 100 30 L 102 100 Z"
            fill="#ef4444"
            stroke="#fff"
            strokeWidth="1"
          />
        </motion.g>
      </svg>
      
      {/* Speed Display */}
      <div className="absolute inset-0 flex items-center justify-center">
        <div className="text-center mt-12">
          <div className="text-5xl font-bold">{value}</div>
          <div className="text-gray-400 text-sm mt-1">MPH</div>
        </div>
      </div>
    </div>
  );
}
