import {
  AlertTriangle,
  Battery,
  Droplets,
  TrendingUp,
  Wrench,
  CircleAlert,
} from 'lucide-react';
import { motion } from 'motion/react';

interface WarningLightsProps {
  speed: number;
  fuel: number;
  temperature: number;
}

export function WarningLights({ speed, fuel, temperature }: WarningLightsProps) {
  const warnings = [
    {
      icon: AlertTriangle,
      active: fuel < 20,
      color: 'text-amber-500',
      label: 'Low Fuel',
    },
    {
      icon: Thermometer,
      active: temperature > 100,
      color: 'text-red-500',
      label: 'High Temp',
    },
    {
      icon: Battery,
      active: false,
      color: 'text-red-500',
      label: 'Battery',
    },
    {
      icon: Droplets,
      active: false,
      color: 'text-blue-500',
      label: 'Oil',
    },
    {
      icon: TrendingUp,
      active: speed > 150,
      color: 'text-orange-500',
      label: 'Over Speed',
    },
    {
      icon: CircleAlert,
      active: false,
      color: 'text-red-500',
      label: 'Check Engine',
    },
  ];

  return (
    <div className="mt-6 flex flex-wrap justify-center gap-4">
      {warnings.map((warning, index) => (
        <motion.div
          key={index}
          className={`flex flex-col items-center gap-1 ${
            warning.active ? warning.color : 'text-gray-600'
          }`}
          animate={
            warning.active
              ? {
                  opacity: [0.5, 1, 0.5],
                  scale: [1, 1.1, 1],
                }
              : {}
          }
          transition={
            warning.active
              ? {
                  duration: 1.5,
                  repeat: Infinity,
                  ease: 'easeInOut',
                }
              : {}
          }
        >
          <warning.icon className="w-6 h-6" />
          <span className="text-xs">{warning.label}</span>
        </motion.div>
      ))}
    </div>
  );
}

function Thermometer({ className }: { className?: string }) {
  return (
    <svg
      className={className}
      width="24"
      height="24"
      viewBox="0 0 24 24"
      fill="none"
      stroke="currentColor"
      strokeWidth="2"
      strokeLinecap="round"
      strokeLinejoin="round"
    >
      <path d="M14 4v10.54a4 4 0 1 1-4 0V4a2 2 0 0 1 4 0Z" />
    </svg>
  );
}
